// CSC 118
// M1HW1 - Movie Talk
// Amy Wright
// January 26, 2020
var name: String
name = "Lair Lair"
print("The reason I chose this movie was because it was truthful and funny")
let date = 1997
print(" ")
print("\(name) was first seen on the big screen in \(date)")
let money = 181.4
let wWend = 31.4
let wWide = 302.7
print("The film made an amazing \(wWend) Million Dollars")
print(" ")
print("In the US a lone it made \(money) Million Dollars")
print(" ")
print("The film made an astonishing \(wWide) Million Dollars")
print(" ")
print("=============================================================")
print("                    Favorite quotes of \(name) ")
print("=============================================================")
print(" ")
print("\"I Wish That For Only One Day, Dad Couldn't Tell A Lie\"")
print(" ")

print("\"I Hold Myself In Contempt!\"")
print(" ")
print("\" I can't Lie\"")
print(" ")

print("\"One of the scenes that I liked the most was when Fletcher's \nson Max made a wish for his dad not to lie for one day\"")
print(" ")
print("\"Another one of the scenes that I liked was when Fletcher was on the \nphone and could not lie and was making all kinds of mumbling noises \nand could not lie to whom ever he was on the phone with\"")
